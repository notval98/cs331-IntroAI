To run on server follow the example:

python program1.py start1.txt goal1.txt bfs output.txt
python program1.py start1.txt goal1.txt dfs output.txt
python program1.py start1.txt goal1.txt iddfs output.txt
python program1.py start1.txt goal1.txt astar output.txt